<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20200513091201 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('CREATE TABLE article (id INT AUTO_INCREMENT NOT NULL, user_id INT NOT NULL, categoria_id INT NOT NULL, titol VARCHAR(255) NOT NULL, subtitol VARCHAR(255) NOT NULL, data_publicacio DATETIME NOT NULL, data_actualitzacio DATETIME DEFAULT NULL, slug VARCHAR(255) NOT NULL, tag_meta LONGTEXT DEFAULT NULL COMMENT \'(DC2Type:array)\', tag_web LONGTEXT DEFAULT NULL COMMENT \'(DC2Type:array)\', contingut MEDIUMTEXT NOT NULL, INDEX IDX_23A0E66A76ED395 (user_id), INDEX IDX_23A0E663397707A (categoria_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE categoria (id INT AUTO_INCREMENT NOT NULL, nom VARCHAR(25) NOT NULL, logo VARCHAR(255) DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE comentari (id INT AUTO_INCREMENT NOT NULL, user_id INT NOT NULL, article_id INT NOT NULL, titol VARCHAR(255) NOT NULL, text VARCHAR(1000) NOT NULL, INDEX IDX_9A59356CA76ED395 (user_id), INDEX IDX_9A59356C7294869C (article_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE homepage_sections (id INT AUTO_INCREMENT NOT NULL, titol VARCHAR(255) NOT NULL, subtitol VARCHAR(255) DEFAULT NULL, contingut LONGTEXT NOT NULL, visible TINYINT(1) NOT NULL, menulink VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE tema (id INT AUTO_INCREMENT NOT NULL, nom VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE user (id INT AUTO_INCREMENT NOT NULL, email VARCHAR(100) NOT NULL, roles LONGTEXT NOT NULL COMMENT \'(DC2Type:array)\', password VARCHAR(255) NOT NULL, nom VARCHAR(40) NOT NULL, cognom VARCHAR(40) NOT NULL, data_naixament DATE DEFAULT NULL, genere VARCHAR(40) DEFAULT NULL, codi_postal VARCHAR(12) DEFAULT NULL, nom_usuari VARCHAR(40) NOT NULL, imatge VARCHAR(200) DEFAULT NULL, ultim_login DATETIME DEFAULT NULL, data_registre DATETIME NOT NULL, github VARCHAR(200) DEFAULT NULL, linkedin VARCHAR(200) DEFAULT NULL, twitter VARCHAR(200) DEFAULT NULL, facebook VARCHAR(200) DEFAULT NULL, UNIQUE INDEX UNIQ_8D93D649E7927C74 (email), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE article ADD CONSTRAINT FK_23A0E66A76ED395 FOREIGN KEY (user_id) REFERENCES user (id)');
        $this->addSql('ALTER TABLE article ADD CONSTRAINT FK_23A0E663397707A FOREIGN KEY (categoria_id) REFERENCES categoria (id)');
        $this->addSql('ALTER TABLE comentari ADD CONSTRAINT FK_9A59356CA76ED395 FOREIGN KEY (user_id) REFERENCES user (id)');
        $this->addSql('ALTER TABLE comentari ADD CONSTRAINT FK_9A59356C7294869C FOREIGN KEY (article_id) REFERENCES article (id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE comentari DROP FOREIGN KEY FK_9A59356C7294869C');
        $this->addSql('ALTER TABLE article DROP FOREIGN KEY FK_23A0E663397707A');
        $this->addSql('ALTER TABLE article DROP FOREIGN KEY FK_23A0E66A76ED395');
        $this->addSql('ALTER TABLE comentari DROP FOREIGN KEY FK_9A59356CA76ED395');
        $this->addSql('DROP TABLE article');
        $this->addSql('DROP TABLE categoria');
        $this->addSql('DROP TABLE comentari');
        $this->addSql('DROP TABLE homepage_sections');
        $this->addSql('DROP TABLE tema');
        $this->addSql('DROP TABLE user');
    }
}
